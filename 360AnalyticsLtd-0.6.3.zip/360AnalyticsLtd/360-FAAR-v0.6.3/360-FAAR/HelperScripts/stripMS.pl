#!/usr/bin/perl -w

while (<>) {
	s/\r//g;
	print;
}
